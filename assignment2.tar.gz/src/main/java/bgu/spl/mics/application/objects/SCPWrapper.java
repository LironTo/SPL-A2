package bgu.spl.mics.application.objects;

import java.util.ArrayList;
import java.util.List;

public class SCPWrapper {
    public int time;
    public String id;
    public List<List<String>> cloudPoints = new ArrayList<>();
}
